from flask import Flask, request, jsonify, send_from_directory
import joblib, json, pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parent
model = joblib.load(BASE / "model.pkl")
with open(BASE / "features.json") as f:
    FEATURES = json.load(f)

app = Flask(__name__, static_folder="../frontend", static_url_path="")


def preprocess_input(data):
    # Accepts: crop, season, area, ph, n, p, k, temp, rain
    row = dict.fromkeys(FEATURES, 0)
    # numeric features
    for k in ["area","ph","n","p","k","temp","rain"]:
        if k in data:
            try:
                row[k] = float(data[k])
            except:
                row[k] = 0.0
    # one-hot for crop and season
    crop = data.get("crop","paddy")
    season = data.get("season","kharif")
    crop_col = f"crop_paddy"
    season_col = f"season_kharif"
    if crop_col in row: row[crop_col] = 1
    if season_col in row: row[season_col] = 1
    return pd.DataFrame([row])

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json or request.form.to_dict()
    df = preprocess_input(data)
    pred = model.predict(df)[0]
    # return predicted t/ha and total for area
    try:
        area = float(data.get("area", 1.0))
    except:
        area = 1.0
    return jsonify({"predicted_yield_t_per_ha": round(float(pred), 3), "predicted_total_tons": round(float(pred)*area,3)})

# simple endpoint to serve frontend files
@app.route('/')
def index():
    return app.send_static_file('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
