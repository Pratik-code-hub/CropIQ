document.addEventListener('DOMContentLoaded', ()=>{
  const form = document.getElementById('predictForm');
  const result = document.getElementById('result');
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    ['area','ph','n','p','k','temp','rain'].forEach(k=> data[k]=Number(data[k]));
    // call backend
    try{
      const res = await fetch('/predict', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
      const j = await res.json();
      result.innerHTML = `<div class="card"><h3>Predicted Yield</h3>
        <p><b>${j.predicted_yield_t_per_ha} t/ha</b> — Total: <b>${j.predicted_total_tons} tons</b></p></div>`;
      // chart
      const ctx = document.getElementById('yieldChart');
      if (ctx){
        if(window._yieldChart) window._yieldChart.destroy();
        window._yieldChart = new Chart(ctx, {type:'bar', data:{labels:['Yield (t/ha)'], datasets:[{label:'t/ha', data:[j.predicted_yield_t_per_ha]}]}});
      }
    }catch(err){
      result.innerHTML = '<div class="card"><p class="small">Cannot reach backend. Start backend server (see backend/app.py)</p></div>';
    }
  });
});
