document.addEventListener('DOMContentLoaded', ()=>{
  // demo district data (could be fetched from backend)
  const districts = ['Cuttack','Puri','Khurda','Ganjam','Sambalpur','Balasore'];
  const yields = [4.2,3.8,4.0,3.5,3.9,4.1];
  const ctx1 = document.getElementById('barYield');
  const ctx2 = document.getElementById('pieRisk');
  new Chart(ctx1, {type:'bar', data:{labels:districts, datasets:[{label:'t/ha', data:yields}]}});
  new Chart(ctx2, {type:'pie', data:{labels:['Low','Medium','High'], datasets:[{data:[55,32,13]}]}});
  document.getElementById('avgYield').textContent = (yields.reduce((a,b)=>a+b,0)/yields.length).toFixed(2);
  document.getElementById('rainAde').textContent = '78%';
  document.getElementById('medProfit').textContent = '₹31,200';
  const alerts = [{date:'2025-09-05',dist:'Cuttack',alert:'Heavy rain expected'},{date:'2025-09-06',dist:'Ganjam',alert:'Heat spike'}];
  document.getElementById('alertsBody').innerHTML = alerts.map(a=>`<tr><td>${a.date}</td><td>${a.dist}</td><td>${a.alert}</td></tr>`).join('');
});
